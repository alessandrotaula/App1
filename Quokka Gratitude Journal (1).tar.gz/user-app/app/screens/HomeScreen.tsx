import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  FlatList,
  Animated,
  Platform,
  KeyboardAvoidingView,
  Modal,
  Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { format } from 'date-fns';
import AsyncStorage from '@react-native-async-storage/async-storage';
import QuokkaMascot from '../components/QuokkaMascot';
import GratitudeEntryInput from '../components/GratitudeEntryInput';
import GratitudeItem from '../components/GratitudeItem';
import GratitudePlaceholder from '../components/GratitudePlaceholder';
import BadgeSystem from '../components/BadgeSystem';
import MinimalProgressBar from '../components/MinimalProgressBar';
import { GratitudeEntry } from '../types/types';
import { MaterialIcons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';

export default function HomeScreen({ navigation }: { navigation: any }) {
  const { isDarkMode, colors } = useTheme();
  
  const [entries, setEntries] = useState<GratitudeEntry[]>([]);
  const [todayEntries, setTodayEntries] = useState<GratitudeEntry[]>([]);
  const [quokkaMessage, setQuokkaMessage] = useState('');
  const [showEntryInput, setShowEntryInput] = useState(false);
  const [totalEntries, setTotalEntries] = useState(0);
  const [showBadgeModal, setShowBadgeModal] = useState(false);
  const [newBadgeUnlocked, setNewBadgeUnlocked] = useState<any>(null);
  
  const fadeAnim = useState(new Animated.Value(0))[0];
  
  const today = format(new Date(), 'yyyy-MM-dd');
  const DAILY_GOAL = 3;
  
  const quokkaMessages = {
    welcome: "Hi there! I'm Quokka, your gratitude buddy. What are you grateful for today?",
    empty: "Start your gratitude practice! What made you smile today?",
    firstEntry: "That's wonderful! Gratitude is a powerful practice. Want to add more?",
    moreEntries: "You're doing great! Each moment of gratitude brightens your day.",
    milestone: "Amazing! You've added 3 things today. You're building a beautiful practice!",
    badgeUnlocked: "Congratulations! You've unlocked a new badge! Keep up the great work!"
  };

  useEffect(() => {
    loadEntries();
    
    setQuokkaMessage(quokkaMessages.welcome);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true
    }).start();
  }, []);

  useEffect(() => {
    // Filter today's entries
    const filtered = entries.filter(entry => entry.date === today);
    setTodayEntries(filtered);
    
    // Update total entries count
    setTotalEntries(entries.length);
    
    // Update quokka message based on entries count
    if (filtered.length === 0) {
      setQuokkaMessage(quokkaMessages.empty);
    } else if (filtered.length === 1) {
      setQuokkaMessage(quokkaMessages.firstEntry);
    } else if (filtered.length === 3) {
      setQuokkaMessage(quokkaMessages.milestone);
    } else if (filtered.length > 1) {
      setQuokkaMessage(quokkaMessages.moreEntries);
    }
    
    // Check for badge unlocks
    checkForBadgeUnlocks(entries.length);
  }, [entries]);

  const loadEntries = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('@gratitude_entries');
      if (jsonValue != null) {
        const loadedEntries = JSON.parse(jsonValue);
        setEntries(loadedEntries);
        
        // Load previously unlocked badges
        const unlockedBadgesJson = await AsyncStorage.getItem('@unlocked_badges');
        if (unlockedBadgesJson) {
          const unlockedBadges = JSON.parse(unlockedBadgesJson);
          // We'll use this later to check for new badge unlocks
        }
      }
    } catch (e) {
      console.error('Failed to load entries', e);
    }
  };

  const saveEntries = async (newEntries: GratitudeEntry[]) => {
    try {
      await AsyncStorage.setItem('@gratitude_entries', JSON.stringify(newEntries));
    } catch (e) {
      console.error('Failed to save entries', e);
    }
  };

  const checkForBadgeUnlocks = async (count: number) => {
    // Define badge thresholds
    const badges = [
      { id: 'beginner', name: 'Beginner', threshold: 3, icon: 'emoji-emotions' },
      { id: 'explorer', name: 'Explorer', threshold: 10, icon: 'explore' },
      { id: 'enthusiast', name: 'Enthusiast', threshold: 25, icon: 'favorite' },
      { id: 'master', name: 'Gratitude Master', threshold: 50, icon: 'stars' }
    ];
    
    try {
      // Get previously unlocked badges
      const unlockedBadgesJson = await AsyncStorage.getItem('@unlocked_badges');
      let unlockedBadges = unlockedBadgesJson ? JSON.parse(unlockedBadgesJson) : [];
      
      // Check for newly unlocked badges
      for (const badge of badges) {
        if (count >= badge.threshold && !unlockedBadges.includes(badge.id)) {
          // New badge unlocked!
          unlockedBadges.push(badge.id);
          setNewBadgeUnlocked(badge);
          setQuokkaMessage(quokkaMessages.badgeUnlocked);
          setShowBadgeModal(true);
          break;
        }
      }
      
      // Save updated unlocked badges
      await AsyncStorage.setItem('@unlocked_badges', JSON.stringify(unlockedBadges));
    } catch (e) {
      console.error('Failed to check for badge unlocks', e);
    }
  };

  const addEntry = (text: string) => {
    const newEntry: GratitudeEntry = {
      id: Date.now().toString(),
      text,
      date: today,
      createdAt: new Date().toISOString()
    };
    
    const newEntries = [...entries, newEntry];
    setEntries(newEntries);
    saveEntries(newEntries);
    setShowEntryInput(false);
  };

  const deleteEntry = (id: string) => {
    const newEntries = entries.filter(entry => entry.id !== id);
    setEntries(newEntries);
    saveEntries(newEntries);
  };

  const renderBadgeModal = () => {
    if (!newBadgeUnlocked) return null;
    
    return (
      <Modal
        visible={showBadgeModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowBadgeModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[
            styles.badgeModalContent,
            { backgroundColor: colors.surface }
          ]}>
            <View style={styles.badgeIconContainer}>
              <MaterialIcons 
                name={newBadgeUnlocked.icon as any} 
                size={60} 
                color="#FFC107" 
              />
              <View style={styles.badgeConfetti}>
                <MaterialIcons name="stars" size={24} color="#FF5722" style={styles.confettiPiece} />
                <MaterialIcons name="stars" size={24} color="#4CAF50" style={[styles.confettiPiece, { top: 10, left: 50 }]} />
                <MaterialIcons name="stars" size={24} color="#2196F3" style={[styles.confettiPiece, { top: -10, left: -40 }]} />
              </View>
            </View>
            
            <Text style={[
              styles.badgeModalTitle,
              { color: colors.text }
            ]}>
              New Badge Unlocked!
            </Text>
            
            <Text style={[
              styles.badgeModalName,
              { color: colors.primary }
            ]}>
              {newBadgeUnlocked.name}
            </Text>
            
            <Text style={[
              styles.badgeModalDescription,
              { color: colors.textSecondary }
            ]}>
              You've reached {newBadgeUnlocked.threshold} gratitude entries! Keep up the great work!
            </Text>
            
            <TouchableOpacity
              style={[
                styles.badgeModalButton,
                { backgroundColor: colors.primary }
              ]}
              onPress={() => setShowBadgeModal(false)}
            >
              <Text style={styles.badgeModalButtonText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };

  return (
    <SafeAreaView style={[
      styles.container,
      { backgroundColor: colors.background }
    ]}>
      <StatusBar style={isDarkMode ? "light" : "dark"} />
      
      <View style={styles.header}>
        <Text style={[
          styles.title,
          { color: colors.primary }
        ]}>Gratitude Journal</Text>
        <TouchableOpacity 
          style={styles.settingsButton}
          onPress={() => navigation.navigate('Settings')}
        >
          <MaterialIcons name="settings" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <MinimalProgressBar 
        current={todayEntries.length} 
        total={DAILY_GOAL} 
      />
      
      <View style={styles.dateContainer}>
        <Text style={[
          styles.date,
          { color: colors.textSecondary }
        ]}>{format(new Date(), 'EEEE, MMMM d')}</Text>
      </View>
      
      <QuokkaMascot message={quokkaMessage} isDarkMode={isDarkMode} />
      
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.mainContent}
        keyboardVerticalOffset={100}
      >
        <View style={styles.entriesContainer}>
          <Text style={[
            styles.sectionTitle,
            { color: colors.text }
          ]}>Today's Gratitude</Text>
          
          {showEntryInput ? (
            <GratitudeEntryInput 
              onAddEntry={addEntry}
              isDarkMode={isDarkMode}
            />
          ) : (
            <>
              <GratitudePlaceholder 
                onPress={() => setShowEntryInput(true)}
                entriesCount={todayEntries.length}
                dailyGoal={DAILY_GOAL}
              />
              {todayEntries.length > 0 && (
                <FlatList
                  data={todayEntries}
                  keyExtractor={(item) => item.id}
                  renderItem={({ item }) => (
                    <GratitudeItem 
                      entry={item} 
                      onDelete={() => deleteEntry(item.id)}
                      isDarkMode={isDarkMode}
                    />
                  )}
                  style={styles.list}
                />
              )}
            </>
          )}
        </View>
      </KeyboardAvoidingView>
      
      {renderBadgeModal()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  settingsButton: {
    padding: 8,
  },
  dateContainer: {
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  date: {
    fontSize: 16,
  },
  mainContent: {
    flex: 1,
  },
  entriesContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginVertical: 10,
  },
  list: {
    flex: 1,
    marginTop: 10,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyStateText: {
    textAlign: 'center',
    fontSize: 16,
    lineHeight: 24,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  badgeModalContent: {
    width: '90%',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
  },
  badgeIconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#FFF9C4',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    position: 'relative',
  },
  badgeConfetti: {
    position: 'absolute',
    width: 120,
    height: 120,
  },
  confettiPiece: {
    position: 'absolute',
  },
  badgeModalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  badgeModalName: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  badgeModalDescription: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 22,
  },
  badgeModalButton: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  badgeModalButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});
