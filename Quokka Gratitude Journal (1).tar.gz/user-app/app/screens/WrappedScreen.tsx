import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { format, subDays, subMonths, parseISO } from 'date-fns';
import { GratitudeEntry } from '../types/types';
import { generateWrappedSummary, WrappedSummary } from '../utils/aiUtils';
import QuokkaMascot from '../components/QuokkaMascot';

export default function WrappedScreen({ navigation }: { navigation: any }) {
  const [loading, setLoading] = useState(false);
  const [weeklySummary, setWeeklySummary] = useState<WrappedSummary | null>(null);
  const [monthlySummary, setMonthlySummary] = useState<WrappedSummary | null>(null);
  const [activeTab, setActiveTab] = useState<'weekly' | 'monthly'>('weekly');
  const [quokkaMessage, setQuokkaMessage] = useState("Let's see what patterns emerge from your gratitude practice!");

  useEffect(() => {
    loadSummaries();
  }, []);

  const loadSummaries = async () => {
    try {
      // Try to load cached summaries first
      const cachedWeekly = await AsyncStorage.getItem('@weekly_summary');
      const cachedMonthly = await AsyncStorage.getItem('@monthly_summary');
      
      if (cachedWeekly) {
        setWeeklySummary(JSON.parse(cachedWeekly));
      }
      
      if (cachedMonthly) {
        setMonthlySummary(JSON.parse(cachedMonthly));
      }
    } catch (error) {
      console.error('Error loading cached summaries:', error);
    }
  };

  const generateSummaries = async () => {
    setLoading(true);
    try {
      // Load all entries
      const jsonValue = await AsyncStorage.getItem('@gratitude_entries');
      if (!jsonValue) {
        Alert.alert('No Entries', 'You need to add some gratitude entries before generating a summary.');
        setLoading(false);
        return;
      }
      
      const allEntries: GratitudeEntry[] = JSON.parse(jsonValue);
      if (allEntries.length < 3) {
        Alert.alert('Not Enough Entries', 'You need at least 3 gratitude entries to generate a meaningful summary.');
        setLoading(false);
        return;
      }
      
      // Get date ranges
      const today = new Date();
      const oneWeekAgo = format(subDays(today, 7), 'yyyy-MM-dd');
      const oneMonthAgo = format(subMonths(today, 1), 'yyyy-MM-dd');
      
      // Filter entries for weekly and monthly
      const weeklyEntries = allEntries.filter(entry => entry.date >= oneWeekAgo);
      const monthlyEntries = allEntries.filter(entry => entry.date >= oneMonthAgo);
      
      // Generate summaries
      if (weeklyEntries.length >= 3) {
        const weekly = await generateWrappedSummary(weeklyEntries, 'weekly');
        if (weekly) {
          setWeeklySummary(weekly);
          await AsyncStorage.setItem('@weekly_summary', JSON.stringify(weekly));
        }
      } else {
        Alert.alert('Weekly Summary', 'Not enough entries in the past week. Add more gratitude moments to see your weekly summary!');
      }
      
      if (monthlyEntries.length >= 5) {
        const monthly = await generateWrappedSummary(monthlyEntries, 'monthly');
        if (monthly) {
          setMonthlySummary(monthly);
          await AsyncStorage.setItem('@monthly_summary', JSON.stringify(monthly));
        }
      } else {
        Alert.alert('Monthly Summary', 'Not enough entries in the past month. Keep adding gratitude moments to see your monthly summary!');
      }
      
      setQuokkaMessage("I've analyzed your gratitude entries! See what patterns emerged in your practice.");
      
    } catch (error) {
      console.error('Error generating summaries:', error);
      Alert.alert('Error', 'Something went wrong while generating your summaries. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const formatDateRange = (startDate?: string, endDate?: string) => {
    if (!startDate || !endDate) return '';
    
    try {
      return `${format(parseISO(startDate), 'MMM d')} - ${format(parseISO(endDate), 'MMM d, yyyy')}`;
    } catch {
      return '';
    }
  };

  const activeSummary = activeTab === 'weekly' ? weeklySummary : monthlySummary;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialIcons name="arrow-back" size={24} color="#6B46C1" />
        </TouchableOpacity>
        <Text style={styles.title}>Gratitude Wrapped</Text>
        <View style={styles.placeholder} />
      </View>
      
      <QuokkaMascot message={quokkaMessage} />
      
      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'weekly' && styles.activeTab
          ]}
          onPress={() => setActiveTab('weekly')}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'weekly' && styles.activeTabText
          ]}>Weekly</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'monthly' && styles.activeTab
          ]}
          onPress={() => setActiveTab('monthly')}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'monthly' && styles.activeTabText
          ]}>Monthly</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.content}>
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#6B46C1" />
            <Text style={styles.loadingText}>Analyzing your gratitude entries...</Text>
          </View>
        ) : activeSummary ? (
          <View style={styles.summaryContainer}>
            <View style={styles.dateRangeContainer}>
              <MaterialIcons name="date-range" size={18} color="#6B46C1" />
              <Text style={styles.dateRange}>
                {formatDateRange(activeSummary.startDate, activeSummary.endDate)}
              </Text>
            </View>
            
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Top Themes</Text>
              <View style={styles.themeContainer}>
                {activeSummary.topThemes.map((theme, index) => (
                  <View key={index} style={styles.themeItem}>
                    <MaterialIcons name="star" size={16} color="#9C27B0" />
                    <Text style={styles.themeText}>{theme}</Text>
                  </View>
                ))}
              </View>
            </View>
            
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Most Frequent Gratitude</Text>
              <Text style={styles.sectionText}>{activeSummary.mostFrequentGratitude}</Text>
            </View>
            
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Insight</Text>
              <Text style={styles.sectionText}>{activeSummary.insightfulObservation}</Text>
            </View>
            
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Personal Growth</Text>
              <Text style={styles.sectionText}>{activeSummary.personalGrowthNote}</Text>
            </View>
            
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Recommended Focus</Text>
              <Text style={styles.sectionText}>{activeSummary.recommendedFocus}</Text>
            </View>
          </View>
        ) : (
          <View style={styles.emptyState}>
            <MaterialIcons name="analytics" size={50} color="#D1C4E9" />
            <Text style={styles.emptyStateText}>
              No {activeTab} summary available yet. Generate a summary to see patterns in your gratitude practice!
            </Text>
          </View>
        )}
      </ScrollView>
      
      <TouchableOpacity 
        style={styles.generateButton}
        onPress={generateSummaries}
        disabled={loading}
      >
        <Text style={styles.generateButtonText}>
          {loading ? 'Generating...' : 'Generate New Summary'}
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F7FF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  backButton: {
    padding: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6B46C1',
  },
  placeholder: {
    width: 34, // Same width as back button for centering
  },
  tabContainer: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 15,
    borderRadius: 25,
    backgroundColor: '#EBE5FF',
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 25,
  },
  activeTab: {
    backgroundColor: '#6B46C1',
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#6B46C1',
  },
  activeTabText: {
    color: 'white',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
  },
  loadingText: {
    marginTop: 15,
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  summaryContainer: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  dateRangeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  dateRange: {
    fontSize: 14,
    color: '#666',
    marginLeft: 5,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#6B46C1',
    marginBottom: 8,
  },
  sectionText: {
    fontSize: 16,
    color: '#333',
    lineHeight: 22,
  },
  themeContainer: {
    marginTop: 5,
  },
  themeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  themeText: {
    fontSize: 16,
    color: '#333',
    marginLeft: 8,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
    paddingHorizontal: 40,
  },
  emptyStateText: {
    textAlign: 'center',
    color: '#888',
    fontSize: 16,
    lineHeight: 24,
    marginTop: 20,
  },
  generateButton: {
    backgroundColor: '#6B46C1',
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginHorizontal: 20,
    marginBottom: 20,
  },
  generateButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});