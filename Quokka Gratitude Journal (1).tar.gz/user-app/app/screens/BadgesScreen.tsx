import React from 'react';
import { SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useTheme } from '../context/ThemeContext';
import BadgeSystem from '../components/BadgeSystem';
import { StatusBar } from 'expo-status-bar';

export default function BadgesScreen() {
  const { colors, isDarkMode } = useTheme();

  return (
    <SafeAreaView style={[
      styles.container,
      { backgroundColor: colors.background }
    ]}>
      <StatusBar style={isDarkMode ? "light" : "dark"} />
      
      <View style={[
        styles.header,
        { borderBottomColor: colors.border }
      ]}>
        <Text style={[
          styles.title,
          { color: colors.primary }
        ]}>
          Your Achievements
        </Text>
      </View>

      <ScrollView style={styles.content}>
        <Text style={[
          styles.description,
          { color: colors.textSecondary }
        ]}>
          Track your gratitude journey through earned badges. Each badge represents a milestone in your practice.
        </Text>
        
        <BadgeSystem />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    padding: 20,
    paddingBottom: 0,
  },
});