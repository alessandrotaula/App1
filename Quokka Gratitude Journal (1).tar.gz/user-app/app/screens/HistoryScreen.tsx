import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  SectionList,
  TouchableOpacity,
  Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { format, parseISO } from 'date-fns';
import { GratitudeEntry } from '../types/types';
import { MaterialIcons } from '@expo/vector-icons';
import Swipeable from 'react-native-gesture-handler/Swipeable';
import { Animated } from 'react-native';

type Section = {
  title: string;
  data: GratitudeEntry[];
};

export default function HistoryScreen() {
  const [sections, setSections] = useState<Section[]>([]);
  const [entries, setEntries] = useState<GratitudeEntry[]>([]);

  useEffect(() => {
    loadEntries();
  }, []);

  useEffect(() => {
    // Group entries by date whenever entries change
    groupEntriesByDate();
  }, [entries]);

  const loadEntries = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('@gratitude_entries');
      if (jsonValue != null) {
        const loadedEntries: GratitudeEntry[] = JSON.parse(jsonValue);
        setEntries(loadedEntries);
      }
    } catch (e) {
      console.error('Failed to load entries', e);
    }
  };

  const saveEntries = async (newEntries: GratitudeEntry[]) => {
    try {
      await AsyncStorage.setItem('@gratitude_entries', JSON.stringify(newEntries));
      setEntries(newEntries);
    } catch (e) {
      console.error('Failed to save entries', e);
    }
  };

  const groupEntriesByDate = () => {
    // Group entries by date
    const groupedEntries: { [key: string]: GratitudeEntry[] } = {};
    
    entries.forEach(entry => {
      if (!groupedEntries[entry.date]) {
        groupedEntries[entry.date] = [];
      }
      groupedEntries[entry.date].push(entry);
    });
    
    // Convert to sections and sort by date (newest first)
    const sectionArray = Object.keys(groupedEntries).map(date => ({
      title: date,
      data: groupedEntries[date]
    }));
    
    sectionArray.sort((a, b) => b.title.localeCompare(a.title));
    
    setSections(sectionArray);
  };

  const deleteEntry = (id: string) => {
    const newEntries = entries.filter(entry => entry.id !== id);
    saveEntries(newEntries);
  };

  const confirmDelete = (id: string) => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this gratitude entry?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => deleteEntry(id) }
      ]
    );
  };

  const renderRightActions = (id: string) => (progress: Animated.AnimatedInterpolation<number>) => {
    const trans = progress.interpolate({
      inputRange: [0, 1],
      outputRange: [100, 0],
    });
    
    return (
      <Animated.View style={{ transform: [{ translateX: trans }] }}>
        <TouchableOpacity 
          style={styles.deleteButton}
          onPress={() => confirmDelete(id)}
        >
          <MaterialIcons name="delete" size={24} color="white" />
        </TouchableOpacity>
      </Animated.View>
    );
  };

  const formatSectionTitle = (dateString: string) => {
    try {
      const date = parseISO(dateString);
      return format(date, 'EEEE, MMMM d, yyyy');
    } catch {
      // If the date is in yyyy-MM-dd format
      const [year, month, day] = dateString.split('-').map(Number);
      const date = new Date(year, month - 1, day);
      return format(date, 'EEEE, MMMM d, yyyy');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.title}>Gratitude History</Text>
      </View>
      
      {sections.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialIcons name="history" size={50} color="#D1C4E9" />
          <Text style={styles.emptyStateText}>
            Your gratitude history will appear here once you start adding entries.
          </Text>
        </View>
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <Swipeable renderRightActions={renderRightActions(item.id)}>
              <View style={styles.entryItem}>
                <MaterialIcons name="favorite" size={16} color="#9C27B0" style={styles.entryIcon} />
                <Text style={styles.entryText}>{item.text}</Text>
              </View>
            </Swipeable>
          )}
          renderSectionHeader={({ section: { title } }) => (
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionHeaderText}>
                {formatSectionTitle(title)}
              </Text>
            </View>
          )}
          stickySectionHeadersEnabled={true}
          contentContainerStyle={styles.listContent}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F7FF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#EBE5FF',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6B46C1',
  },
  listContent: {
    paddingBottom: 20,
  },
  sectionHeader: {
    backgroundColor: '#EBE5FF',
    padding: 10,
    paddingHorizontal: 20,
  },
  sectionHeaderText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B46C1',
  },
  entryItem: {
    flexDirection: 'row',
    padding: 15,
    paddingHorizontal: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    alignItems: 'flex-start',
  },
  entryIcon: {
    marginRight: 10,
    marginTop: 2,
  },
  entryText: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  deleteButton: {
    backgroundColor: '#FF5252',
    justifyContent: 'center',
    alignItems: 'center',
    width: 80,
    height: '100%',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyStateText: {
    textAlign: 'center',
    color: '#888',
    fontSize: 16,
    lineHeight: 24,
    marginTop: 20,
  },
});
