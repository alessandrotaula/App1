import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Switch, 
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
  Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { MaterialIcons } from '@expo/vector-icons';
import QuokkaMascot from '../components/QuokkaMascot';
import { useTheme } from '../context/ThemeContext';

export default function SettingsScreen({ navigation }: { navigation: any }) {
  const { isDarkMode, toggleTheme, colors } = useTheme();
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [notificationTime, setNotificationTime] = useState('20:00');
  const [customMessage, setCustomMessage] = useState('Time for your daily gratitude practice!');
  const [quokkaMessage, setQuokkaMessage] = useState("Customize your experience here! I'll remind you to practice gratitude.");

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const settings = await AsyncStorage.getItem('@gratitude_settings');
      if (settings) {
        const parsedSettings = JSON.parse(settings);
        setNotificationsEnabled(parsedSettings.notificationsEnabled || false);
        setNotificationTime(parsedSettings.notificationTime || '20:00');
        setCustomMessage(parsedSettings.customMessage || 'Time for your daily gratitude practice!');
      }
    } catch (e) {
      console.error('Failed to load settings', e);
    }
  };

  const saveSettings = async () => {
    try {
      const settings = {
        notificationsEnabled,
        notificationTime,
        customMessage
      };
      await AsyncStorage.setItem('@gratitude_settings', JSON.stringify(settings));
      
      if (notificationsEnabled) {
        await scheduleNotification();
      } else {
        await cancelNotifications();
      }
      
      Alert.alert('Success', 'Your settings have been saved!');
    } catch (e) {
      console.error('Failed to save settings', e);
      Alert.alert('Error', 'Failed to save settings. Please try again.');
    }
  };

  const registerForPushNotificationsAsync = async () => {
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'default',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF231F7C',
      });
    }

    if (Device.isDevice) {
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      
      if (finalStatus !== 'granted') {
        Alert.alert(
          'Permission Required',
          'Please enable notifications in your device settings to receive reminders.',
          [{ text: 'OK' }]
        );
        setNotificationsEnabled(false);
        return false;
      }
      return true;
    } else {
      Alert.alert('Physical Device Required', 'Notifications require a physical device.');
      setNotificationsEnabled(false);
      return false;
    }
  };

  const scheduleNotification = async () => {
    const hasPermission = await registerForPushNotificationsAsync();
    if (!hasPermission) return;

    await cancelNotifications();

    const [hours, minutes] = notificationTime.split(':').map(Number);
    
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Gratitude Journal',
        body: customMessage,
        sound: true,
      },
      trigger: {
        hour: hours,
        minute: minutes,
        repeats: true,
      },
    });
  };

  const cancelNotifications = async () => {
    await Notifications.cancelAllScheduledNotificationsAsync();
  };

  const toggleNotifications = (value: boolean) => {
    setNotificationsEnabled(value);
  };

  return (
    <SafeAreaView style={[
      styles.container,
      { backgroundColor: colors.background }
    ]}>
      <StatusBar style={isDarkMode ? "light" : "dark"} />
      
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialIcons name="arrow-back" size={24} color={colors.primary} />
        </TouchableOpacity>
        <Text style={[
          styles.title,
          { color: colors.primary }
        ]}>Settings</Text>
        <View style={styles.placeholder} />
      </View>
      
      <QuokkaMascot message={quokkaMessage} />
      
      <ScrollView style={styles.content}>
        <View style={[
          styles.section,
          { backgroundColor: colors.surface, borderColor: colors.border }
        ]}>
          <Text style={[
            styles.sectionTitle,
            { color: colors.primary }
          ]}>Appearance</Text>
          
          <View style={[
            styles.settingRow,
            { borderBottomColor: colors.border }
          ]}>
            <Text style={[
              styles.settingLabel,
              { color: colors.text }
            ]}>Dark Mode</Text>
            <Switch
              value={isDarkMode}
              onValueChange={toggleTheme}
              trackColor={{ false: '#D1C4E9', true: '#9C27B0' }}
              thumbColor={isDarkMode ? '#B794F4' : '#f4f3f4'}
            />
          </View>
        </View>
        
        <View style={[
          styles.section,
          { backgroundColor: colors.surface, borderColor: colors.border }
        ]}>
          <Text style={[
            styles.sectionTitle,
            { color: colors.primary }
          ]}>Notifications</Text>
          
          <View style={[
            styles.settingRow,
            { borderBottomColor: colors.border }
          ]}>
            <Text style={[
              styles.settingLabel,
              { color: colors.text }
            ]}>Daily Reminder</Text>
            <Switch
              value={notificationsEnabled}
              onValueChange={toggleNotifications}
              trackColor={{ false: '#D1C4E9', true: '#9C27B0' }}
              thumbColor={notificationsEnabled ? colors.primary : '#f4f3f4'}
            />
          </View>
          
          {notificationsEnabled && (
            <>
              <View style={[
                styles.settingRow,
                { borderBottomColor: colors.border }
              ]}>
                <Text style={[
                  styles.settingLabel,
                  { color: colors.text }
                ]}>Reminder Time</Text>
                <TextInput
                  style={[
                    styles.timeInput,
                    { 
                      borderColor: colors.border,
                      color: colors.text,
                      backgroundColor: isDarkMode ? colors.background : colors.surface
                    }
                  ]}
                  value={notificationTime}
                  onChangeText={setNotificationTime}
                  placeholder="20:00"
                  placeholderTextColor={colors.textSecondary}
                  keyboardType="numbers-and-punctuation"
                />
              </View>
              
              <View style={styles.messageInputContainer}>
                <Text style={[
                  styles.settingLabel,
                  { color: colors.text }
                ]}>Custom Message</Text>
                <TextInput
                  style={[
                    styles.messageInput,
                    { 
                      borderColor: colors.border,
                      color: colors.text,
                      backgroundColor: isDarkMode ? colors.background : colors.surface
                    }
                  ]}
                  value={customMessage}
                  onChangeText={setCustomMessage}
                  placeholder="Enter your custom reminder message"
                  placeholderTextColor={colors.textSecondary}
                  multiline
                  maxLength={100}
                />
                <Text style={[
                  styles.characterCount,
                  { color: colors.textSecondary }
                ]}>
                  {customMessage.length}/100
                </Text>
              </View>
            </>
          )}
        </View>
        
        <View style={[
          styles.section,
          { backgroundColor: colors.surface, borderColor: colors.border }
        ]}>
          <Text style={[
            styles.sectionTitle,
            { color: colors.primary }
          ]}>About</Text>
          <Text style={[
            styles.aboutText,
            { color: colors.textSecondary }
          ]}>
            Gratitude Journal is a simple app to help you practice daily gratitude.
            Research shows that regularly noting things you're grateful for can improve
            your mental well-being and overall happiness.
          </Text>
          <Text style={[
            styles.versionText,
            { color: colors.textSecondary }
          ]}>Version 1.0.0</Text>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.saveButton,
            { backgroundColor: colors.primary }
          ]}
          onPress={saveSettings}
        >
          <Text style={styles.saveButtonText}>Save Settings</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  backButton: {
    padding: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 34, // Same width as back button for centering
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 30,
    borderRadius: 12,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
    borderWidth: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 15,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  settingLabel: {
    fontSize: 16,
  },
  timeInput: {
    borderWidth: 1,
    borderRadius: 5,
    padding: 8,
    width: 80,
    textAlign: 'center',
    fontSize: 16,
  },
  messageInputContainer: {
    marginTop: 15,
  },
  messageInput: {
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginTop: 8,
    fontSize: 16,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  characterCount: {
    alignSelf: 'flex-end',
    marginTop: 5,
    fontSize: 12,
  },
  aboutText: {
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 10,
  },
  versionText: {
    fontSize: 12,
    textAlign: 'right',
    marginTop: 10,
  },
  saveButton: {
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginVertical: 20,
  },
  saveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});
