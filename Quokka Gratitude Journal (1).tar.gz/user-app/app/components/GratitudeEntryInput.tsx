import React, { useState } from 'react';
import { 
  View, 
  TextInput, 
  StyleSheet, 
  TouchableOpacity,
  Keyboard,
  Alert,
  Platform
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as Speech from 'expo-speech';

type GratitudeEntryInputProps = {
  onAddEntry: (text: string) => void;
  isDarkMode?: boolean;
};

export default function GratitudeEntryInput({ onAddEntry, isDarkMode = false }: GratitudeEntryInputProps) {
  const [text, setText] = useState('');
  const [isListening, setIsListening] = useState(false);

  const handleAddEntry = () => {
    if (text.trim().length > 0) {
      onAddEntry(text.trim());
      setText('');
      Keyboard.dismiss();
    }
  };

  const startSpeechToText = async () => {
    try {
      setIsListening(true);
      
      if (Platform.OS === 'ios') {
        Alert.prompt(
          'Voice Recognition',
          'What are you grateful for today?',
          [
            {
              text: 'Cancel',
              onPress: () => setIsListening(false),
              style: 'cancel',
            },
            {
              text: 'Add',
              onPress: (speechText) => {
                if (speechText && speechText.trim()) {
                  setText(speechText.trim());
                }
                setIsListening(false);
              },
            },
          ],
          'plain-text'
        );
      } else {
        Alert.alert(
          'Voice Recognition',
          'Speech-to-text is not available on this device.',
          [{ text: 'OK', onPress: () => setIsListening(false) }]
        );
      }
    } catch (error) {
      console.error('Error with speech recognition:', error);
      setIsListening(false);
      Alert.alert('Error', 'Could not process speech. Please try again or type your entry.');
    }
  };

  const speakText = async () => {
    if (text.trim()) {
      try {
        await Speech.stop();
        await Speech.speak(text.trim(), {
          language: 'en',
          pitch: 1.0,
          rate: 0.9,
          onError: (error) => {
            console.error('Speech error:', error);
            Alert.alert('Error', 'Could not speak the text. Please try again.');
          },
        });
      } catch (error) {
        console.error('Error with text-to-speech:', error);
        Alert.alert('Error', 'Could not speak the text. Please try again.');
      }
    }
  };

  return (
    <View style={[
      styles.container,
      isDarkMode && styles.containerDark
    ]}>
      <View style={styles.inputContainer}>
        <TextInput
          style={[
            styles.input,
            isDarkMode && styles.inputDark
          ]}
          value={text}
          onChangeText={setText}
          placeholder="What are you grateful for today?"
          placeholderTextColor={isDarkMode ? '#999' : '#666'}
          multiline
          maxLength={200}
          color={isDarkMode ? '#FFFFFF' : '#333333'}
        />
        
        <View style={styles.inputActions}>
          <TouchableOpacity 
            style={[
              styles.actionButton,
              { opacity: text.trim().length > 0 ? 1 : 0.5 }
            ]}
            onPress={speakText}
            disabled={text.trim().length === 0}
          >
            <MaterialIcons 
              name="volume-up" 
              size={22} 
              color={isDarkMode ? '#B794F4' : '#6B46C1'} 
            />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.actionButton,
              { opacity: isListening ? 0.5 : 1 }
            ]}
            onPress={startSpeechToText}
            disabled={isListening}
          >
            <MaterialIcons 
              name="mic" 
              size={22} 
              color={isDarkMode ? '#B794F4' : '#6B46C1'} 
            />
          </TouchableOpacity>
        </View>
      </View>
      
      <TouchableOpacity 
        style={[
          styles.addButton,
          { opacity: text.trim().length > 0 ? 1 : 0.5 },
          isDarkMode && styles.addButtonDark
        ]}
        onPress={handleAddEntry}
        disabled={text.trim().length === 0}
      >
        <MaterialIcons name="add" size={24} color="white" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderTopWidth: 1,
    borderTopColor: '#EBE5FF',
    backgroundColor: 'white',
  },
  containerDark: {
    backgroundColor: '#1A1A1A',
    borderTopColor: '#333333',
  },
  inputContainer: {
    flex: 1,
    position: 'relative',
  },
  input: {
    backgroundColor: '#F9F7FF',
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 10,
    paddingRight: 80,
    fontSize: 16,
    maxHeight: 100,
    color: '#333',
  },
  inputDark: {
    backgroundColor: '#333333',
    color: '#FFFFFF',
  },
  inputActions: {
    position: 'absolute',
    right: 10,
    top: 8,
    flexDirection: 'row',
  },
  actionButton: {
    padding: 5,
    marginLeft: 5,
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#6B46C1',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
  },
  addButtonDark: {
    backgroundColor: '#B794F4',
  },
});
