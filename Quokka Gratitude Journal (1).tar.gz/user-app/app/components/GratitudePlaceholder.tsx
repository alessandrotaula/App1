import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Dimensions 
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';

type GratitudePlaceholderProps = {
  onPress: () => void;
};

export default function GratitudePlaceholder({ 
  onPress
}: { onPress: () => void }) {
  const { colors, isDarkMode } = useTheme();
  
  return (
    <TouchableOpacity 
      style={[
        styles.container,
        { 
          borderColor: colors.border,
          backgroundColor: isDarkMode ? 'rgba(183, 148, 244, 0.1)' : 'rgba(107, 70, 193, 0.05)'
        }
      ]}
      onPress={onPress}
    >
      <MaterialIcons 
        name="add-circle-outline" 
        size={32} 
        color={colors.primary} 
      />
      
      <Text style={[
        styles.text,
        { color: colors.text }
      ]}>
        Add a gratitude moment
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    borderWidth: 2,
    borderStyle: 'dashed',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
    height: 120,
  },
  text: {
    fontSize: 16,
    fontWeight: '500',
    marginTop: 10,
  },
});
