import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../context/ThemeContext';

type MinimalProgressBarProps = {
  current: number;
  total: number;
};

export default function MinimalProgressBar({ current, total }: MinimalProgressBarProps) {
  const { colors, isDarkMode } = useTheme();
  const progress = Math.min((current / total) * 100, 100);

  return (
    <View style={styles.container}>
      <View style={[
        styles.progressContainer,
        { backgroundColor: isDarkMode ? 'rgba(183, 148, 244, 0.1)' : 'rgba(107, 70, 193, 0.05)' }
      ]}>
        <View
          style={[
            styles.progressBar,
            { 
              width: `${progress}%`,
              backgroundColor: colors.primary
            }
          ]}
        />
        <Text style={[
          styles.progressText,
          { color: colors.textSecondary }
        ]}>
          {current}/{total} Today
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  progressContainer: {
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
    position: 'relative',
    justifyContent: 'center',
  },
  progressBar: {
    position: 'absolute',
    left: 0,
    top: 0,
    height: '100%',
    borderRadius: 18,
  },
  progressText: {
    textAlign: 'center',
    fontSize: 14,
    fontWeight: '500',
  },
});