import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity 
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';

// Define badge milestones
const BADGES = [
  { id: 'beginner', name: 'Beginner', icon: 'emoji-emotions', threshold: 3, color: '#4CAF50' },
  { id: 'explorer', name: 'Explorer', icon: 'explore', threshold: 10, color: '#2196F3' },
  { id: 'enthusiast', name: 'Enthusiast', icon: 'favorite', threshold: 25, color: '#9C27B0' },
  { id: 'master', name: 'Gratitude Master', icon: 'stars', threshold: 50, color: '#FFC107' },
];

type BadgeSystemProps = {
  totalEntries: number;
  onBadgePress?: (badge: typeof BADGES[0]) => void;
};

export default function BadgeSystem({ totalEntries, onBadgePress }: BadgeSystemProps) {
  const { colors, isDarkMode } = useTheme();
  
  // Calculate which badges are unlocked
  const unlockedBadges = BADGES.filter(badge => totalEntries >= badge.threshold);
  const nextBadge = BADGES.find(badge => totalEntries < badge.threshold);
  
  return (
    <View style={styles.container}>
      <Text style={[
        styles.title,
        { color: colors.text }
      ]}>
        Your Badges ({unlockedBadges.length}/{BADGES.length})
      </Text>
      
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.badgesContainer}
      >
        {BADGES.map(badge => {
          const isUnlocked = totalEntries >= badge.threshold;
          
          return (
            <TouchableOpacity
              key={badge.id}
              style={[
                styles.badge,
                { 
                  backgroundColor: isUnlocked 
                    ? isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'
                    : isDarkMode ? '#2D2D2D' : '#F0F0F0',
                  borderColor: isUnlocked ? badge.color : isDarkMode ? '#444' : '#DDD'
                }
              ]}
              onPress={() => onBadgePress && onBadgePress(badge)}
              disabled={!isUnlocked}
            >
              <View style={[
                styles.iconContainer,
                { 
                  backgroundColor: isUnlocked ? badge.color : isDarkMode ? '#444' : '#DDD',
                  opacity: isUnlocked ? 1 : 0.5
                }
              ]}>
                <MaterialIcons 
                  name={badge.icon as any} 
                  size={24} 
                  color={isUnlocked ? 'white' : isDarkMode ? '#888' : '#999'} 
                />
              </View>
              
              <Text style={[
                styles.badgeName,
                { 
                  color: isUnlocked ? colors.text : colors.textSecondary,
                  opacity: isUnlocked ? 1 : 0.7
                }
              ]}>
                {badge.name}
              </Text>
              
              <Text style={[
                styles.badgeRequirement,
                { color: isUnlocked ? badge.color : colors.textSecondary }
              ]}>
                {isUnlocked ? 'Unlocked!' : `${badge.threshold} entries`}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      
      {nextBadge && (
        <View style={[
          styles.nextBadgeContainer,
          { 
            backgroundColor: isDarkMode ? colors.cardBackground : colors.surface,
            borderColor: colors.border
          }
        ]}>
          <Text style={[
            styles.nextBadgeText,
            { color: colors.textSecondary }
          ]}>
            Next badge: {nextBadge.name} ({totalEntries}/{nextBadge.threshold} entries)
          </Text>
          <View style={[
            styles.nextBadgeProgress,
            { backgroundColor: isDarkMode ? '#333' : '#EBE5FF' }
          ]}>
            <View 
              style={[
                styles.nextBadgeProgressBar,
                { 
                  width: `${(totalEntries / nextBadge.threshold) * 100}%`,
                  backgroundColor: nextBadge.color
                }
              ]} 
            />
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 15,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
    paddingHorizontal: 20,
  },
  badgesContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
  },
  badge: {
    width: 100,
    height: 130,
    borderRadius: 12,
    marginHorizontal: 5,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  badgeName: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 5,
  },
  badgeRequirement: {
    fontSize: 12,
    textAlign: 'center',
  },
  nextBadgeContainer: {
    marginTop: 15,
    marginHorizontal: 20,
    padding: 15,
    borderRadius: 12,
    borderWidth: 1,
  },
  nextBadgeText: {
    fontSize: 14,
    marginBottom: 10,
  },
  nextBadgeProgress: {
    height: 8,
    borderRadius: 4,
    overflow: 'hidden',
  },
  nextBadgeProgressBar: {
    height: '100%',
  }
});