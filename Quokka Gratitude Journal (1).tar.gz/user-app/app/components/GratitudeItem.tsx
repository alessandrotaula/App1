import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity,
  Alert
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { GratitudeEntry } from '../types/types';
import { format, parseISO } from 'date-fns';
import { GestureHandlerRootView, Swipeable } from 'react-native-gesture-handler';

type GratitudeItemProps = {
  entry: GratitudeEntry;
  onDelete: () => void;
};

export default function GratitudeItem({ entry, onDelete }: GratitudeItemProps) {
  const confirmDelete = () => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this gratitude entry?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: onDelete }
      ]
    );
  };

  const renderRightActions = () => {
    return (
      <TouchableOpacity 
        style={styles.deleteButton}
        onPress={confirmDelete}
      >
        <MaterialIcons name="delete" size={24} color="white" />
      </TouchableOpacity>
    );
  };

  const formatTime = (dateString: string) => {
    try {
      const date = parseISO(dateString);
      return format(date, 'h:mm a');
    } catch {
      return '';
    }
  };

  return (
    <GestureHandlerRootView>
      <Swipeable
        renderRightActions={renderRightActions}
        overshootRight={false}
      >
        <View style={styles.container}>
          <View style={styles.iconContainer}>
            <MaterialIcons name="favorite" size={20} color="#9C27B0" />
          </View>
          <View style={styles.contentContainer}>
            <Text style={styles.text}>{entry.text}</Text>
            {entry.createdAt && (
              <Text style={styles.time}>{formatTime(entry.createdAt)}</Text>
            )}
          </View>
        </View>
      </Swipeable>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 12,
    marginVertical: 6,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  iconContainer: {
    marginRight: 12,
    paddingTop: 2,
  },
  contentContainer: {
    flex: 1,
  },
  text: {
    fontSize: 16,
    color: '#333',
    lineHeight: 22,
  },
  time: {
    fontSize: 12,
    color: '#888',
    marginTop: 5,
  },
  deleteButton: {
    backgroundColor: '#FF5252',
    justifyContent: 'center',
    alignItems: 'center',
    width: 80,
    height: '100%',
    borderTopRightRadius: 12,
    borderBottomRightRadius: 12,
  },
});
