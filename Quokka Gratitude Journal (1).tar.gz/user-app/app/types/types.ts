export type GratitudeEntry = {
  id: string;
  text: string;
  date: string; // Format: YYYY-MM-DD
  createdAt: string; // ISO string
};

export type NotificationSettings = {
  enabled: boolean;
  time: string; // Format: HH:MM
  message: string;
};