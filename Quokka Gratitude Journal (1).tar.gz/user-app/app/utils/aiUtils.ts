import OpenAI from 'openai';
import { GratitudeEntry } from '../types/types';

// Initialize OpenAI with a placeholder API key
// In a production app, you would use environment variables or secure storage
const openai = new OpenAI({
  apiKey: process.env.EXPO_PUBLIC_OPENAI_API_KEY || 'placeholder-api-key',
  dangerouslyAllowBrowser: true // For client-side usage
});

export type WrappedSummary = {
  period: 'weekly' | 'monthly';
  startDate: string;
  endDate: string;
  topThemes: string[];
  mostFrequentGratitude: string;
  insightfulObservation: string;
  personalGrowthNote: string;
  recommendedFocus: string;
};

export async function generateWrappedSummary(
  entries: GratitudeEntry[],
  period: 'weekly' | 'monthly'
): Promise<WrappedSummary | null> {
  if (!entries.length) return null;
  
  try {
    // Format entries for the prompt
    const entriesText = entries
      .map(entry => `Date: ${entry.date}, Entry: "${entry.text}"`)
      .join('\n');
    
    // Create the prompt
    const prompt = `
      Analyze these gratitude journal entries and create a ${period} summary:
      
      ${entriesText}
      
      Create a personalized "${period}" summary that includes:
      1. Top 3-5 themes or patterns
      2. Most frequent type of gratitude
      3. One insightful observation about the entries
      4. A note about personal growth visible in the entries
      5. A recommendation for what to focus gratitude on next
      
      Format the response as JSON with the following structure:
      {
        "topThemes": ["theme1", "theme2", "theme3"],
        "mostFrequentGratitude": "description",
        "insightfulObservation": "observation",
        "personalGrowthNote": "growth note",
        "recommendedFocus": "recommendation"
      }
    `;
    
    // Call the OpenAI API
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an AI assistant that analyzes gratitude journal entries to identify patterns, themes, and insights. Your responses are thoughtful, encouraging, and personalized."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the response
    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("No content in response");
    
    const parsedContent = JSON.parse(content);
    
    // Sort entries to find date range
    const sortedEntries = [...entries].sort((a, b) => a.date.localeCompare(b.date));
    const startDate = sortedEntries[0].date;
    const endDate = sortedEntries[sortedEntries.length - 1].date;
    
    // Return the wrapped summary
    return {
      period,
      startDate,
      endDate,
      ...parsedContent
    };
  } catch (error) {
    console.error('Error generating wrapped summary:', error);
    return null;
  }
}