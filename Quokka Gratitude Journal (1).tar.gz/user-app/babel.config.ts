module.exports = {
  plugins: [
    'react-native-reanimated/plugin',
  ],
};